<?php
/**
 * The template for homepage posts with "Excerpt" style
 *
 * @package WordPress
 * @subpackage GUTENTYPE
 * @since GUTENTYPE 1.0
 */

gutentype_storage_set( 'blog_archive', true );

get_header();

if ( have_posts() ) {

	gutentype_blog_archive_start();

	?><div class="posts_container">
		<?php

		$gutentype_stickies   = is_home() ? get_option( 'sticky_posts' ) : false;
		$gutentype_sticky_out = gutentype_get_theme_option( 'sticky_style' ) == 'columns'
								&& is_array( $gutentype_stickies ) && count( $gutentype_stickies ) > 0 && get_query_var( 'paged' ) < 1;
		if ( $gutentype_sticky_out ) {
			?>
			<div class="sticky_wrap columns_wrap">
			<?php
		}

        $middle_count = round(min($GLOBALS['wp_query']->found_posts, get_query_var('posts_per_page'))/2);
        $middle_count = $middle_count > 1 ? $middle_count + 1 : $middle_count;
        $count = 0;
        $gutentype_widgets_blog_page = gutentype_get_theme_option( 'widgets_blog_page' );
        $gutentype_show_widgets = ! gutentype_is_off( $gutentype_widgets_blog_page ) && is_active_sidebar( $gutentype_widgets_blog_page );

		while ( have_posts() ) {
			the_post();
			if ( $gutentype_sticky_out && ! is_sticky() ) {
				$gutentype_sticky_out = false;
				?>
				</div>
				<?php
			}
			$gutentype_part = $gutentype_sticky_out && is_sticky() ? 'sticky' : 'excerpt';
			get_template_part( apply_filters( 'gutentype_filter_get_template_part', 'content', $gutentype_part ), $gutentype_part );


            $count++;
            if($count == $middle_count){
                if ( $gutentype_show_widgets ) { ?>
                    <div class="blog_widgets_wrap sc_layouts_row sc_layouts_row_type_normal">
                        <?php gutentype_create_widgets_area( 'widgets_blog_page' ); ?>
                    </div>
                    <?php
                }
            }

		}
		if ( $gutentype_sticky_out ) {
			$gutentype_sticky_out = false;
			?>
			</div>
			<?php
		}

		?>
	</div>
	<?php

	gutentype_show_pagination();

	gutentype_blog_archive_end();

} else {

	if ( is_search() ) {
		get_template_part( apply_filters( 'gutentype_filter_get_template_part', 'content', 'none-search' ), 'none-search' );
	} else {
		get_template_part( apply_filters( 'gutentype_filter_get_template_part', 'content', 'none-archive' ), 'none-archive' );
	}
}

get_footer();
