<?php
// Add plugin-specific vars to the custom CSS
if ( ! function_exists( 'gutentype_gutenberg_add_theme_vars' ) ) {
	add_filter( 'gutentype_filter_add_theme_vars', 'gutentype_gutenberg_add_theme_vars', 10, 2 );
	function gutentype_gutenberg_add_theme_vars( $rez, $vars ) {
		return $rez;
	}
}


// Add plugin-specific colors and fonts to the custom CSS
if ( ! function_exists( 'gutentype_gutenberg_get_css' ) ) {
	add_filter( 'gutentype_filter_get_css', 'gutentype_gutenberg_get_css', 10, 2 );
	function gutentype_gutenberg_get_css( $css, $args ) {

		if ( isset( $css['vars'] ) && isset( $args['vars'] ) ) {
			extract( $args['vars'] );
			$css['vars'] .= <<<CSS

CSS;
		}

		if ( isset( $css['colors'] ) && isset( $args['colors'] ) ) {
			$colors         = $args['colors'];
			$css['colors'] .= <<<CSS




.style-bg:before,
.style-bg-top:before,
.style-bg-left:before  {
	background-color: {$colors['alter_bg_color']};
}



CSS;
		}

		return $css;
	}
}

